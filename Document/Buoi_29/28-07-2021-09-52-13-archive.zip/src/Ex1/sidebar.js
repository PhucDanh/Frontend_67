import React, { Component } from 'react';
import './sidebar.css'
class Sidebar extends Component {
    render() {
        return (
            <div className="sidebar">
                Sidebar
            </div>
        );
    }
}

export default Sidebar;