// action creator
export const createAction = (type, payload) => {
  // return action object
  return {
    type,
    payload,
  };
};
