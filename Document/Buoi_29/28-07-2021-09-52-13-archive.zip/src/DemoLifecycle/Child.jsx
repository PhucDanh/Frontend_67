import React, { Component, PureComponent } from "react";

class Child extends Component {
  shouldComponentUpdate(nextProps, nextState) {
    return true;
  }
  render() {
    console.log("Child render!!");
    return (
      <div>
        <h3>Child Component</h3>
        <h3>Title: {this.props.item.title}</h3>
        <h3>Author: {this.props.item.author}</h3>
        <hr />
      </div>
    );
  }
}

export default Child;
