import React, { Component } from "react";
import Child from "./Child";
import { handleError } from "../helpers/handleError";

// let timer;

class Parent extends Component {
  constructor(props) {
    super(props);
    console.log("constructor");
    this.state = {
      counter: 0,
      counter2: 0,
      childList: [
        { title: "title1", author: "Hieu" },
        { title: "title2", author: "Dung" },
        { title: "title3", author: "Tai" },
      ],
      hasError: false,
    };
  }

  //   componentWillMount(){}
  shouldComponentUpdate(nextProps, nextState) {
    console.log("should compoennt update", nextState);
    return true;
  }

  increaseCounter = () => {
    this.setState({
      counter: this.state.counter + 1,
    });
  };

  increaseCounter2 = () => {
    // this.setState({
    //   counter2: this.state.counter2 + 1,
    // });
    throw "loi rồi";
  };

  renderChildren = () => {
    return this.state.childList.map((item) => {
      return <Child key={item.title} item={item} />;
    });
  };

  changeChild = () => {
    const cloneChildList = [...this.state.childList];
    cloneChildList[0].author = "Hoang";
    this.setState({
      childList: cloneChildList,
    });
  };

  render() {
    console.log("render");
    if (this.state.hasError) {
      return "Something went wrong!";
    }

    return (
      <div>
        <h1>Parent Component</h1>
        <hr noshade="1" />
        <button onClick={this.changeChild}>Change child list</button>
        <button onClick={this.increaseCounter}>Increase</button>
        <button onClick={this.increaseCounter2}>Increase counter2</button>
        {/* <Child counter2={this.state.counter2} /> */}
        {this.renderChildren()}
      </div>
    );
  }

  componentDidMount() {
    //đoạn code chạy lúc đầu và một lần duy nhất
    console.log("call api");

    // setTimeout(() => {
    //   handleError("Call API fail 1!");
    // }, 2000);

    // setTimeout(() => {
    //   handleError("Call API fail! 2");
    // }, 4000);

    // timer = setInterval(() => {
    //   console.log("interval!!");
    // }, 10000);
  }
  componentDidUpdate(prevProps, prevState) {
    console.log("did update,", prevState);
  }

  //lifecycle chạy khi component bị ẩn khỏi cây dom

  componentWillUnmount() {
    // clean up code
    // clearInterval(timer);
  }
}

export default Parent;
