import DemoLifeCycle from "./DemoLifecycle/Parent";
import ErrorBoundary from "./DemoLifecycle/ErrorBoundary";

function App() {
  return (
    <ErrorBoundary>
      <DemoLifeCycle />
    </ErrorBoundary>
  );
}

export default App;
