export const handleError = (err) => {
  alert(err);
};
