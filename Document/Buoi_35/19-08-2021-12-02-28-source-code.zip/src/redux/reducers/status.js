const inititalState = {
  isRevealed: false,
};

const reducer = (state = inititalState, { type, payload }) => {
  switch (type) {
    case "SET_REVEALED":
      state.isRevealed = payload;
      return { ...state };
    default:
      return state;
  }
};

export default reducer;
