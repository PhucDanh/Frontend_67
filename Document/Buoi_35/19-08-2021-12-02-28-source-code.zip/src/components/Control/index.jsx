import React, { memo, useCallback, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";

const Control = () => {
  useEffect(() => {
    console.log("Control Render!!!!");
  });

  const players = useSelector((state) => {
    return state.player.playerList;
  });

  const deckCard = useSelector((state) => {
    return state.card.deckCard;
  });

  const dispatch = useDispatch();

  const handleFetchCards = useCallback(async () => {
    try {
      const res = await axios({
        method: "GET",
        url: `https://deckofcardsapi.com/api/deck/${deckCard.deck_id}/draw/?count=12`,
      });
      // res.data.cards là mảng 12 lá
      console.log(res.data.cards);
      // chia 12 lá bài cho 4 player
      const playerList = [...players];

      for (let i in res.data.cards) {
        const playerIndex = i % playerList.length;
        playerList[playerIndex].cards.push(res.data.cards[i]);
        // i = 0 => playerIndex = 0
        // i = 1 => playerIndex = 1
        // i = 2 => playerIndex = 2
        // i = 3 => playerIndex = 3
        // i = 4 => playerIndex = 0
        // i = 5 => playerIndex = 1
      }

      // dispatch nguyên playerList mới lên reducer
      dispatch({ type: "SET_PLAYERS", payload: playerList });
    } catch (err) {
      console.log(err);
    }
  }, [dispatch, players, deckCard]);

  const handleRevealCards = useCallback(() => {
    dispatch({ type: "SET_REVEALED", payload: true });
  }, [dispatch]);

  const checkResult = useCallback(() => {
    const playerList = [...players];

    const winners = [];

    // check special Cases 

    // nếu ko có special cases, covert rồi cộng điểm từng player rồi tìm max

    // update điểm cho người thắng

    // dispatch lên store cập nhật playerList

  }, []);

  //nhận vào mảng cards của players ,check bằng value, nếu 
  //cả 3 lá đều là KING JACK QUEEN thì là trường hợp đặt biệt
  const checkSpecialCases = (cards) => {
    
  }
  // nhận vào value của card => number
  // number => number
  // KING JACK QUEEN => 10
  // ACE => 1
  const convertCardValue = (val) => {}
  

  return (
    <div className="d-flex  justify-content-end container">
      <div className="border d-flex justify-content-center align-items-center px-2">
        <button className="btn btn-success mr-2">Shuffle</button>
        <button className="btn btn-info mr-2" onClick={handleFetchCards}>
          Draw
        </button>
        <button onClick={handleRevealCards} className="btn btn-primary mr-2">
          Reveal
        </button>
      </div>
      <div className="d-flex">
        {players.map((player) => {
          return (
            <div key={player.username} className="border px-3 text-center">
              <p>{player.username}</p>
              <p> {player.totalPoint} </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default memo(Control);
