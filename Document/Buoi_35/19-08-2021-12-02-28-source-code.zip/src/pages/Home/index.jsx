import React, { useState } from "react";
import Game from "../Game";
import { useFormik } from "formik";
import * as yup from "yup";
import { useDispatch } from "react-redux";

const schema = yup.object().shape({
  username: yup.string().required("This is is required!"),
  email: yup
    .string()
    .required("This is is required!")
    .email("Email is invalid!"),
  phone: yup
    .string()
    .required("This is is required!")
    .matches(/^[0-9]+$/g),
});

const Home = () => {
  const [isGameStarted, setIsGameStarted] = useState(false);
  // const [a, setA] = useState("");
  // const [v, setV] = useState(0);

  const {
    values,
    errors,
    touched,
    isValid,
    handleChange,
    handleBlur,
    setTouched,
  } = useFormik({
    initialValues: {
      username: "Trung Hieu",
      email: "dangtrunghieu@gmail.com",
      phone: "0334643124",
    },
    validationSchema: schema,
    validateOnMount: true,
  });

  const dispatch = useDispatch();

  const handleSubmit = (event) => {
    event.preventDefault();
    setTouched({
      username: true,
      email: true,
      phone: true,
    });

    if (!isValid) return;

    const newPlayer = {
      ...values,
      totalPoint: 25000,
      cards: [],
    };

    dispatch({
      type: "ADD_PLAYER",
      payload: newPlayer,
    });

    setIsGameStarted(true);
  };

  return (
    <>
      {isGameStarted ? (
        <Game />
      ) : (
        <div
          className="text-center"
          style={{
            width: "100vw",
            height: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <h1 className="diplay-4 mb-5"> Welcome to Pocker Center</h1>
          <h3>Fill your info and start</h3>
          <form onSubmit={handleSubmit} className="w-25 ">
            <input
              name="username"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.username}
              type="input"
              placeholder="username"
              className="w-100 form-control mb-3"
            />
            {touched.username && (
              <p className="text-danger">{errors.username}</p>
            )}
            <input
              name="email"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.email}
              type="input"
              placeholder="email"
              className="w-100 form-control mb-3"
            />
            {touched.email && <p className="text-danger">{errors.email}</p>}
            <input
              name="phone"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.phone}
              type="input"
              placeholder="phone"
              className="w-100 form-control mb-3"
            />
            {touched.phone && <p className="text-danger">{errors.phone}</p>}

            <button className="btn btn-success">Start new Game</button>
          </form>
        </div>
      )}
    </>
  );
};

export default Home;
