// //Global scope
// console.log("Hello world from outside");
// // Biến (variable)
// var fullName = "Đặng Trung Hiếu";
// var age = 12;

// fullName = "Phan Đình Dũng";

// console.log(fullName, age);

// // kiểu dữ liệu :

// // 1. number
// var num = 10;
// var num2 = 10.22;
// // 2. string
// var email = "hieu@gmail.com";
// // 3.boolean
// var isHandsome = false;
// // 4.null vs undefined
// var phone;
// var gender = null;

// // toán tử và lệnh gán
// var res1 = 1 + 2;
// var res2 = 2 - 1;
// var res3 = 6 / 3;
// var res4 = 4 % 3; // 1
// var res5 = 4 * 5;

// res1++;
// // res1 = res1 + 1

// res2--;
// // res2 = res2 -1

// res3 += 2;
// //res3 = res3 + 2

// res3 -= 4;
// //res3 = res3 -4

// res4 *= 2;
// // res4 = res4 * 2

// res5 /= 4;
// // res5 = res5 / 4

// res5 %= 2;
// // res5 = res5 % 2

// console.log(res3, res4, res5);

// // hàm
// // scope: phạm vi sử dụng của biến

// // function scope
// // function calcSum(a, b) {
// //   //biến cục bộ
// //   var sum = a + b;
// //   return sum;
// // }

// // var res = calcSum(1, 3);

// // console.log(res)

// // câu điều kiện

// // var n = 7;

// // if (n > 5) {
// //   console.log(n, "Lớn hơn 5");
// // } else {
// //   console.log(n, "nhỏ hơn 5");
// // }

// function calcSalary() {
//   /**
//    * input: số giờ làm, tiền mỗi giờ
//    *
//    * process:
//    *     - tạo 2 biến workingHours, salaryPerHour
//    *     - tính lương : 2 trường hợp dưới 40h và trên 40h, hệ số OT 1.5
//    *     - console.log lương tính được
//    *
//    * output: tiền lương
//    */
//   var workingHour = 45;
//   var salaryPerHour = 10;
//   var totalSalary;
//   if (workingHour <= 40) {
//     totalSalary = workingHour * salaryPerHour;
//   } else {
//     totalSalary = 40 * salaryPerHour + (workingHour - 40) * salaryPerHour * 1.5;
//   }

//   console.log(totalSalary);
// }

// calcSalary();

function calcAverage(math, physics, chemistry) {
  // input: toán, lí , hoá
  var average = (math + physics + chemistry) / 3;
  return average;
  // output: return điểm trung bình
}

function classify(average) {
  // input: điểm trung bình

  // process: sử dụng if else, check điểm tb => loại
  // output: return loại ("Giỏi" | "Khá" | "TB")

  var type;
  if (average >= 8.5) {
    type = "Giỏi";
  } else if (average >= 6.5) {
    type = "Khá";
  } else if (average >= 5) {
    type = "TB";
  } else {
    type = "Yếu";
  }

  return type;
}

function main() {
  /**
   * input: ho tên, điểm toán, lí , hoá
   *
   * process:
   *   1. tạo biến name, math, physics, chemistry
   *   2. tính điểm trung bình
   *   3. xếp loại
   *   4. In đtb và loại ra màn hình
   *
   * output: điểm trung bình | xếp loại
   *
   */

  var name = "Hiếu";
  var math = 10;
  var physics = 8;
  var chemistry = 1;

  var average = calcAverage(math, physics, chemistry);

  var type = classify(average);

  console.log(
    "Sinh viên " + name + " có điểm tb là: " + average + "và xếp loại: " + type
  );
}

main();
