import React, { Component } from "react";

class Detail extends Component {
  render() {
    const { name, screen, backCamera, frontCamera, img, desc } =
      this.props.selectedProduct;

    return (
      <div className="container mt-5">
        <div className="row">
          <div className="col-4">
            <h4>{name}</h4>
            <img src={img} alt="product" className="w-100" />
          </div>
          <div className="col-8">
            <h4>Thông số kĩ thuật</h4>
            <table className="table">
              <tr>
                <td>Màn hình</td>
                <td>{screen}</td>
              </tr>
              <tr>
                <td>Camera Trước</td>
                <td>{frontCamera}</td>
              </tr>
              <tr>
                <td>Camera sau</td>
                <td>{backCamera}</td>
              </tr>
              <tr>
                <td>Mô tả</td>
                <td>{desc}</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

export default Detail;
