// //------------------------------- Khai báo biến với var let const ------
// /*
//     Phân biệt sự khác biệt giữa var và let
//     + Khi khai báo = từ khoá let thì trong phạm vi 1 scope không được khai báo trùng tên biến. Đối với var khai báo như vậy thì giá trị biến sau sẽ đè giá trị biến trước.
//     + Phạm vi hoạt động từ khoá var trên toàn scope. Phạm vi hoạt động từ khoá let trên từng scope.
//     + Lưu ý trong es6 nên dùng let cho tất cả trường hợp
//     + Khi khai báo biến bằng từ khoá const phạm vi hoạt động giống let tuy nhiên giá trị không thể gán lại được

// */

// let hoTen = 'Nguyễn Văn A'; //file 1
// {

//     hoTen = 'Trần Văn C'; //file 2
//     console.log('hoTen', hoTen);
// }
// console.log('hoTen', hoTen); //file 3
// //Định nghĩa sự kiện cho các button số
// //var button1 = document.getElementById('#btn1');
// // button1.onclick = function() { alert ...}

// //arrButton = [button1,button2,button3]
// let arrButton = document.querySelectorAll('button');

// for (let i = 0; i < arrButton.length; i++) {
//     //Mỗi lần duyệt lấy ra 1 button
//     var button = arrButton[i];
//     button.onclick = function () {
//         alert(i + 1);
//     }
// }

// //const 
// const domain = 'https://api.cybyersoft.vn';

// const settings = {
//     domain: 'https://api.cybyersoft.vn',
//     ip: '192.168.1.1'
// }

// // ----------------------- hoisting ----------------------
// // Hỗ trợ var tự động khai báo biến
// var title;
// console.log(title);
// var title = 'cybersoft';
// // --------------------- arrow function ------------------------
// /*
//     + Đối với hàm có 1 tham số arrowfunction cho phép rút gọn ()
//     + Đối với hàm có 1 lệnh return arrowfunction cho phép rút gọn {} và chữ return
//     + Arrow function không thể tạo prototype như function được
// */
// //es5
// function showMessage(mess) {
//     return mess;
// }

// showMessage('Hello Nam');
// // var showMessage = function (mess) {
// //     return mess;
// // }
// //es6 
// let showMessageES6 = mess => 'Hello' + mess;
// console.log(showMessageES6('Nam'));
// //Dom đến button#btn1
// let domId = id => document.getElementById(id);
// domId('btn1').style.background = 'red'
// // ------------------- context (this) ngữ cảnh con trỏ this -----------
// /*
//     + Mặc định con trỏ this sẽ trỏ về window
//     + this sử dụng trong đối tượng thì this sẽ là đối tượng đó
//     + this sử dụng trong prototype (lớp đối tượng ) thì this sẽ là prototype đó
// */
// // this.email = 'abc@gmail.com';
// // var email =  'abc@gmail.com';
// // window.email = 'abc@gmail.com';
// // console.log('email',email)
// // console.log('this',window.innerHeight);
// // console.log('this',window.innerWidth);
// window.hoTen = 'abc';
// let hocVien = {
//     ma: 1,
//     hoTen: 'Nguyễn Văn A',
//     hienThiThongTin: function () {
//         let hienThi = () => {
//             console.log('Mã', this.ma);
//             console.log('Họ tên', this.hoTen);
//         }
//         hienThi();
//     }
// }
// hocVien.hienThiThongTin();

// // -------------------------- Restparameter ----------------------------




// function tinhTong(...restParams) { // [1,2] | [1,2,3]
   
//     switch(restParams.length) {
//         case 2: { 
//             console.log(restParams[0] + restParams[1]);
//         };break;
//         case 3: { 
//             console.log(restParams[0] + restParams[1] + restParams[2]);
//         };break;
//         default : {
//             console.log('Tham số đầu vào không hợp lệ!')
//         }
//     }

// }

// tinhTong(1,2);
// tinhTong(1,2,3);
// tinhTong(1,2,3,4,5);

// // ------------------------------------ spread operator -----------------------------


// let hocVien1 = {ma:5,hoTen:'Nguyễn Văn A'};
// let hocVien2 = {...hocVien1,lop:'FE67',hoTen:'Nguyễn Văn Tèo'};

// console.log('hocVien1',hocVien1);
// console.log('hocVien2',hocVien2);



// let arr1 = [1,2,3,4];
// let arr2 = [...arr1,1,2,4,4,5,6,4];

// // arr2.push(5);

// console.log('arr1',arr1)
// console.log('arr2',arr2)

// // ----------------------- Default Params ---------------------
// // Khi gọi hàm truyền tham số thì hàm sẽ sử dụng tham số mình truyền, khi không truyền tham số thì hàm sử dụng tham số mặc định

// function hienThiThongTin(ten = 'Trực',namSinh = 2000, tuoi = 2020 - namSinh) {

//     console.log('ten',ten);
//     console.log('namSinh',namSinh);
//     console.log('tuoi',tuoi);
// }


// hienThiThongTin('Khải',2001);
// hienThiThongTin('Khải',2001,15);

// //-------------------------- Destructuring ------------------

// let hocVienCybersoft = {
//     maHV:'01',
//     hoTenHV:'Trần Thị B',
//     lop:'FrontEnd 67',
//     hienThiThongTinHocVien : function () {
//         console.log('Tên',hocVienCybersoft.hoTenHV);
//     }
// }
// //ES5 tạo biến dựa trên thuộc tính
// // let maHV = hocVienCybersoft.maHV;
// // let hoTenHV = hocVienCybersoft.hoTenHV;

// //ES6
// let {hoTenHV,hienThiThongTinHocVien,...restParam} = hocVienCybersoft;
// console.log(restParam);
// hienThiThongTinHocVien();

// // --------------------------------- object literal ------------------

// let maSP = 'mã sản phẩm'

// let tenSanPham = 'IPhone XS MAX';

// let sanPham = {
//     [maSP]:'IP1',
//     tenSanPham:tenSanPham,
//     gia: 1000
// }

// console.log('sanPham',sanPham['mã sản phẩm']);

// // ------------------------- for in - for of ----------------------------------
// // for in thường dùng để duyệt object (các thuộc tính và giá trị của object)
// // for of thường dùng để duyệt các phần tử (object) trong mảng
// let arrProduct = [
//     {id:1,name:'Iphone X',price:3000},
//     {id:2,name:'Sony XZ',price:2000},
//     {id:3,name:'Galaxy Note 10 plus',price:1000},
// ]


// for (let tenThuocTinh in sanPham) {
//     console.log(tenThuocTinh, sanPham[tenThuocTinh]);
// }


// for(let index in arrProduct) {
//     //Mỗi lần duyệt lấy ra 1 sản phẩm
//     let product = arrProduct[index];
//     let id = arrProduct[index].id;

//     console.log(`Index [${index}] = `, product)
// }






// for (let product of arrProduct) {
//     console.log('product',product);
// }


// Giải bài tập
document.querySelector('#btnHienThi').onclick = function(){ 
    //Lấy thông tin người dùng nhập vào
    let arrInput = document.querySelectorAll('form input, form select');
    let hocVien = {maHocVien:'123',hoTen:'abc',};
    for(let i = 0 ; i < arrInput.length ; i++ ){
        //Mỗi lần duyệt lấy ra 1 thẻ
        let input = arrInput[i];
        //Lấy các thuộc tính từ dom input
        let {value,id,name} = input;
        //Từ thuộc tính tạo ra object 
        hocVien = {...hocVien,[name]:value}
    }
    //Duyệt các tên thuộc tính và giá trị thuộc tính của object
    let contentTable = '<tr>';
    for(let tenThuocTinh in hocVien) {
        contentTable += `
            <td>${hocVien[tenThuocTinh]}</td>
        `
    }
    contentTable += '</tr>';
    document.querySelector('#tblHocVien').innerHTML = contentTable;

}