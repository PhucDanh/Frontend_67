"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
console.log("Hello World!!");
console.log("Demo typescript");
// TYPESCRIPT = ES6 + TYPES + OOP
// ES6
var fullName = "Dang Trung Hieu";
var age = 12;
var showName = function () {
    console.log(fullName);
};
showName();
var student = { name: "hieu", email: "hieu@gmail.com" };
var studentName = student.name, email = student.email;
console.log(studentName, email);
// ---------TYPES------------
var isLoggedIn = true;
var content = "hello";
var num = 4;
var emails = ["hieu@gmail.com", "12"];
var course = { name: "angular", rating: 5 };
var courses = [
    { name: "Angular", rating: 4 },
    { name: "react", rating: 5 },
];
var studentInfo = ["hieu", 13];
var colors;
(function (colors) {
    // key = value
    colors["green"] = "#00ff00";
    colors["blue"] = "#0000ff";
})(colors || (colors = {}));
var statusType;
(function (statusType) {
    statusType["active"] = "ACTIVE";
    statusType["inactive"] = "INACTIVE";
})(statusType || (statusType = {}));
var userStatus = statusType.active;
console.log(userStatus);
var color = colors.green;
console.log(colors.green, colors.blue);
var response = {};
var rating = null;
var description = undefined;
var res = "BE";
var res2 = 1323;
var res3 = 12;
// Function Types
function showMessage(message) {
    console.log(message);
}
// function sum(a: number, b: number): number {
//   return a + b;
// }
var sum = function (a, b) {
    return a + b;
};
var Student = /** @class */ (function () {
    function Student(name, age, phone) {
        this.name = name;
        this._age = age;
        this.phone = phone;
        this.gender = "male";
    }
    Object.defineProperty(Student.prototype, "age", {
        get: function () {
            return this._age;
        },
        set: function (val) {
            //
            this._age = val;
        },
        enumerable: false,
        configurable: true
    });
    Student.prototype.getInfo = function () {
        return this.name + this.phone;
    };
    return Student;
}());
var Student2 = /** @class */ (function (_super) {
    __extends(Student2, _super);
    function Student2(name, age, phone) {
        var _this = _super.call(this, name, age, phone) || this;
        _this.age = 1;
        return _this;
    }
    return Student2;
}(Student));
var newStudent = new Student("hieu", 15, "0334643124");
//set new age
newStudent.age = 19;
//get age
console.log(newStudent.age, student.name);
