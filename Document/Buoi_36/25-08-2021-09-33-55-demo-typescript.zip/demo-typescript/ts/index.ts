console.log("Hello World!!");
console.log("Demo typescript");

// TYPESCRIPT = ES6 + TYPES + OOP

// ES6
const fullName = "Dang Trung Hieu";
let age = 12;

const showName = () => {
  console.log(fullName);
};

showName();

const student = { name: "hieu", email: "hieu@gmail.com" };

const { name: studentName, email } = student;

console.log(studentName, email);

// ---------TYPES------------

const isLoggedIn: boolean = true;

const content: string = "hello";

const num: number = 4;

const emails: string[] = ["hieu@gmail.com", "12"];

const course: { name: string; rating: number } = { name: "angular", rating: 5 };

const courses: { name: string; rating: number }[] = [
  { name: "Angular", rating: 4 },
  { name: "react", rating: 5 },
];

const studentInfo: [string, number] = ["hieu", 13];

enum colors {
  // key = value
  green = "#00ff00",
  blue = "#0000ff",
}

enum statusType {
  active = "ACTIVE",
  inactive = "INACTIVE",
}

const userStatus: statusType = statusType.active;

console.log(userStatus);

const color: colors = colors.green;

console.log(colors.green, colors.blue);

const response: any = {};

const rating: null = null;

const description: undefined = undefined;

// Advanced Types

// union type
// Type Aliases
type resType = number | string | undefined;

const res: resType = "BE";

const res2: resType = 1323;
const res3: resType = 12;

// Function Types

function showMessage(message: string): void {
  console.log(message);
}

// function sum(a: number, b: number): number {
//   return a + b;
// }

const sum = (a: number, b: number): number => {
  return a + b;
};

// ------- OOP --------------

interface IStudent {
  name: string;
  phone: string;
  getInfo(): string;
}

class Student implements IStudent {
  public name: string;
  //   private age: number;
  protected _age: number;
  public phone: string;
  public gender: string;

  constructor(name: string, age: number, phone: string) {
    this.name = name;
    this._age = age;
    this.phone = phone;
    this.gender = "male";
  }

  get age() {
    return this._age;
  }

  set age(val: number) {
    //
    this._age = val;
  }

  getInfo() {
    return this.name + this.phone;
  }
}

class Student2 extends Student {
  constructor(name: string, age: number, phone: string) {
    super(name, age, phone);
    this.age = 1;
  }
}

const newStudent = new Student("hieu", 15, "0334643124");

//set new age
newStudent.age = 19;

//get age
console.log(newStudent.age, student.name);
