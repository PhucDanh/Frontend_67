import React, { Fragment, useEffect, useState } from "react";
import "./index.css";
import Controls from "../../components/Control";
import Main from "../../components/Main";

const Game = () => {
  const [count, setCount] = useState(0);
  const [count2, setCount2] = useState(0);
  //Didmount, didupdate, willunmount

  //didmount
  useEffect(() => {
    console.log("useEffect Didmount");
    //call api
  }, []);

  //did update
  useEffect(() => {
    console.log(count2);
  }, [count2]);

  return (
    <Fragment>
      <button onClick={() => setCount(count + 1)}>Set Count</button>
      <button onClick={() => setCount2(count2 + 1)}>Set Count 2</button>
      <Controls />
      <Main />
    </Fragment>
  );
};

export default Game;
