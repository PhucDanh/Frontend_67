import React, { Component } from "react";
import "./model.css";
import { connect } from "react-redux";

class Model extends Component {
  render() {
    return (
      <div
        style={{
          background: `url(${this.props.selectedProducts.background || './assets/img/background/background_998.jpg'})`,
        }}
        className="contain"
      >
        <div
          style={{ background: "url(./assets/img/allbody/bodynew.png)" }}
          className="body"
        />
        <div
          style={{ background: "url(./assets/img/model/1000new.png)" }}
          className="model"
        />
        <div
          style={{ background: "url(./assets/img/allbody/bikini_branew.png)" }}
          className="bikinitop"
        />
        <div
          style={{
            background: "url(./assets/img/allbody/bikini_pantsnew.png)",
          }}
          className="bikinibottom"
        />
        <div
          style={{
            background: "url(./assets/img/allbody/feet_high_leftnew.png)",
          }}
          className="feetleft"
        />
        <div
          style={{
            background: "url(./assets/img/allbody/feet_high_rightnew.png)",
          }}
          className="feetright"
        />

        <div
          style={{
            backgroundImage: `url(${this.props.selectedProducts.topclothes})`,
            backgroundSize: "cover",
          }}
          className="bikinitop"
        ></div>

        <div
          style={{
            backgroundImage: `url(${this.props.selectedProducts.botclothes})`,
            backgroundSize: "cover",
          }}
          className="bikinibottom"
        ></div>

        <div
          style={{
            backgroundImage: `url(${this.props.selectedProducts.shoes})`,
            backgroundSize: "cover",
            width: "500px",
            height: "1000px",
            position: "absolute",
            bottom: "-39.5%",
            right: "-3.5%",
            transform: "scale(0.5)",
            zIndex: "1",
          }}
        ></div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    selectedProducts: state.product.selectedProducts,
  };
};

export default connect(mapStateToProps)(Model);
