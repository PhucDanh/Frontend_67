import React, { Component } from "react";
import { connect } from "react-redux";
import { createAction } from "../store/actions/index";

class ProductItem extends Component {
  handleTryCloth = () => {
    this.props.dispatch(
      createAction("SET_PRODUCT", {
        type: this.props.prod.type,
        img: this.props.prod.imgSrc_png,
      })
    );
  };
  render() {
    const { imgSrc_jpg, name } = this.props.prod;
    return (
      <div className="card mb-3">
        <img src={imgSrc_jpg} alt="product" />
        <div className="card-body">
          <p className="lead">{name}</p>
          <button onClick={this.handleTryCloth} className="btn btn-success">
            Thử
          </button>
        </div>
      </div>
    );
  }
}

export default connect()(ProductItem);
