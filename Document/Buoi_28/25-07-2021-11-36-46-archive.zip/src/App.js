import Home from "./DressingRoom/Home";

function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
