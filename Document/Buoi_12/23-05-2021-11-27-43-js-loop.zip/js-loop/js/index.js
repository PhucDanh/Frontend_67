// var n = 101;

// while (n <= 100) {
//   console.log(n);
//   n++;
//   //   n += 2;
//   //   //n = n + 2
// }

// do {
//   console.log(n);
//   n++;
// } while (n <= 100);

// for

for (var n = 1; n <= 100; n++) {
  console.log(n);
}
