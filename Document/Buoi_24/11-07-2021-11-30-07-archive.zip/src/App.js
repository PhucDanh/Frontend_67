import MovieExercise from "./Ex3";

function App() {
  return (
    <div>
      <MovieExercise />
    </div>
  );
}

export default App;
