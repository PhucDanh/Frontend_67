export const actionType = {
  SET_COURSES: "SET_COURSES",
  SET_COURSE: "SET_COURSE",
};
