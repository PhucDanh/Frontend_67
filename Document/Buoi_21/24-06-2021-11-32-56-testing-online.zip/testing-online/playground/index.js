//module
//import thường
import { fullName, showMessage } from "./demo.js";
//import default, không cần ngoặc, tên gì cũng đc
import Student from "./student.js";

console.log("index");

console.log(fullName);

showMessage();

const newStudent = new Student();
console.log(newStudent);
