// truethy: còn lại / falsy : 0, "", null, undefined, false
var a = 5;
if ("aa") {
  //code
  console.log("right");
}

console.log(1 && "aaaa");
console.log("" && "aaaa");
console.log("" || 2);
console.log("" || 0 || "1");

// filter : hàm lọc mảng

const numbers = [2, 5, 1, 3, 8, 9, 6];

const filteredNumbers = numbers.filter((item) => {
  return item >= 5;
});

console.log(filteredNumbers);

// import / export
export const fullName = "hieu";
export const showMessage = () => {
  console.log("hello world");
};

let arrInput = document.querySelectorAll("form select, form input");
