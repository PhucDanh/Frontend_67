class Student {
  constructor() {
    this.id = 1;
    this.name = "hieu";
  }
}
//export thường, có thể export bao nhiêu biến tuỳ ý
export const a = 5;
export const b = 5;

//export mặc định, một file chỉ được export mặc định 1 lần
export default Student;
