class FillInBlank extends Question {
  constructor(type, id, content, answers) {
    super(type, id, content, answers);
  }

  checkExact() {
    const userAnswer = document.getElementById("answer-" + this.id).value;
    return userAnswer.toLowerCase() === this.answers[0].content.toLowerCase();
  }

  render(index) {
    return `
          <div>
              <h3>Câu hỏi ${index}: ${this.content} </h3>
              <input id="answer-${this.id}" />
          </div>
        `;
  }
}
