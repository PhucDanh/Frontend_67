class MultipleChoice extends Question {
  constructor(type, id, content, answers) {
    super(type, id, content, answers);
  }

  checkExact() {
    // 1.check xem người dùng chọn ô input nào => id của đáp án đang chọn
    let answerId;
    const answerInputs = document.getElementsByClassName("answer-" + this.id);
    for (let answerInput of answerInputs) {
      if (answerInput.checked) {
        answerId = answerInput.value;
      }
    }
    // 2.check người dùng có chọn đáp án hay ko, nếu ko chọn => false
    if (!answerId) return false;
    // 3. dựa vào id lấy đc, tìm ra đối tượng đáp án trong ds đáp án => exact

    const foundedAnswer = this.answers.find((item) => {
      return item.id === answerId;
    });

    return foundedAnswer.exact;
  }

  render(index) {
    let answersHTML = "";

    for (let item of this.answers) {
      answersHTML += `
            <div>
                <input value="${item.id}" type="radio" class="answer-${this.id}" name="answer-${this.id}" />
                <label >${item.content}</label>
            </div>
        `;
    }

    return `
        <div>
            <h3>Câu hỏi ${index}: ${this.content} </h3>
            ${answersHTML}
        </div>
      `;
  }
}

const newQuestion = new MultipleChoice("1", "13232", "Hôm nay là thứ mấy?", [
  { content: "Thứ 2" },
  { content: "Thứ 5" },
  { content: "Thứ 7" },
  { content: "CN" },
]);

console.log(newQuestion.render());
