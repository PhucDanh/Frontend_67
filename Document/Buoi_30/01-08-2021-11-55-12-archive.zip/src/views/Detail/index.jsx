import React, { Component } from 'react';

class Detail extends Component {
    render() {
        return (
            <div>
                <h1>DETAIL PAGE</h1>
            </div>
        );
    }
}

export default Detail;