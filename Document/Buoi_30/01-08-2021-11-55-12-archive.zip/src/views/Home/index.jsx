import React, { Component } from "react";
import Header from "../../components/Header";
import { Typography, Container, Grid } from "@material-ui/core";
import CourseItem from "../../components/CourseItem";
class Home extends Component {
  render() {
    return (
      <div>
        <Header></Header>

        <Typography component="h1" variant="h3" align="center" gutterBottom>
          Danh sách khoá học
        </Typography>

        <Container maxWidth="lg">
          <Grid container spacing={3}>
            <Grid xs={12} sm={6} md={3} item>
              <CourseItem />
            </Grid>
            <Grid xs={12} sm={6} md={3} item>
              <CourseItem />
            </Grid>
            <Grid xs={12} sm={6} md={3} item>
              <CourseItem />
            </Grid>
            <Grid xs={12} sm={6} md={3} item>
              <CourseItem />
            </Grid>
          </Grid>
        </Container>
      </div>
    );
  }
}

export default Home;
