import React, { Component } from 'react';
import Detail from './views/Detail';
import Home from './views/Home';
import Signin from './views/Signin';
import Signup from './views/Signup';
import {BrowserRouter, Switch, Route} from 'react-router-dom'

class App extends Component {
  render() {
    return (
      <BrowserRouter>
       
        <Switch>
            <Route path="/detail" component={Detail} />
            <Route path="/signin" component={Signin} />
            <Route path="/signup" component={Signup} />
            <Route path="/" component={Home} />
        </Switch>
      </BrowserRouter>
    );
  }
}

export default App;