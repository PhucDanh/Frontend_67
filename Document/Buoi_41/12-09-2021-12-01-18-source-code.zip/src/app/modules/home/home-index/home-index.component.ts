import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { IMovie } from 'src/app/models/movie';
import { MovieDataService } from 'src/app/services/movie-data.service';

@Component({
  selector: 'app-home-index',
  templateUrl: './home-index.component.html',
  styleUrls: ['./home-index.component.scss'],
})
export class HomeIndexComponent implements OnInit {
  //dependency injection
  constructor(
    private _movieService: MovieDataService,
    private _http: HttpClient
  ) {}

  moveList: IMovie[] = [];

  fetchMovies(): void {
    this._http
      .get('https://movienew.cybersoft.edu.vn/api/QuanLyPhim/LayDanhSachPhim', {
        params: {
          maNhom: 'GP01',
        },
        headers: {
          TokenCybersoft:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5Mb3AiOiJGcm9udCBFbmQgNjciLCJIZXRIYW5TdHJpbmciOiIyOS8wMS8yMDIyIiwiSGV0SGFuVGltZSI6IjE2NDM0MTQ0MDAwMDAiLCJuYmYiOjE2MTc1NTU2MDAsImV4cCI6MTY0MzU2MjAwMH0.N1IDGkovxIU1E2CjtI_QtEJksOO3lxZxuIwXABaa45w',
        },
      })
      .subscribe(
        (res: any) => {
          //cập nhật dữ liệu trên service
          this._movieService.setMovieList(res.content);
        },
        (err) => {
          console.log(err);
        }
      );
  }

  ngOnInit(): void {
    //call api fetch movie List
    this.fetchMovies();

    this._movieService.movieList.subscribe((val) => {
      this.moveList = val;
    });

    //   console.log('did mount của angular: oninit');
    //   // Promise: axios
    //   const promise = new Promise((resolve, reject) => {
    //     // call api
    //     setTimeout(() => {
    //       resolve('data');
    //       // reject('error');
    //     }, 2000);
    //   });
    //   //front xử lý : axios() => promise
    //   promise
    //     .then((res) => {
    //       console.log(res, 'data backend tra ve');
    //     })
    //     .catch((err) => {
    //       console.log(err);
    //     });
    //   // Observable: get(), post(), put()
    //   const observable = new Observable((resolver) => {
    //     setTimeout(() => {
    //       resolver.next('data 1');
    //       resolver.next('data 2');
    //       resolver.next('data 3');
    //       // resolver.error('error 1');
    //     }, 2000);
    //   });
    //   //frontent xử lý: get() => observable
    //   observable.subscribe(
    //     (res) => {
    //       console.log(res);
    //     },
    //     (err) => {
    //       console.log(err);
    //     }
    //   );
  }

  handleDelete(): void {
    this._movieService.deleteMovie(1288);
  }
}
