import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-index',
  templateUrl: './detail-index.component.html',
  styleUrls: ['./detail-index.component.scss']
})
export class DetailIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
