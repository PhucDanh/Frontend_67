import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IMovie } from '../models/movie';

@Injectable({
  providedIn: 'root',
})
export class MovieDataService {
  movieList = new BehaviorSubject<IMovie[]>([]);

  deleteMovie(id: number) {
    let movieListData = this.movieList.getValue();
    movieListData = movieListData.filter((item) => item.maPhim !== id);

    this.movieList.next(movieListData);
  }

  setMovieList(data: IMovie[]) {
    this.movieList.next(data);
  }

  constructor() {}
}
