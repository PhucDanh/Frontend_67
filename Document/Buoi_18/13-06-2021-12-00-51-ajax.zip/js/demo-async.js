//synchronous: đồng bộ

var a = 5;
var b = 10;
var sum = a + b;
console.log(sum);
console.log(a);

//asynchronous: Bất đồng bộ

setTimeout(function () {
  console.log("b");
}, 4000);

setTimeout(function () {
  console.log("d");
}, 0);

console.log("c");
