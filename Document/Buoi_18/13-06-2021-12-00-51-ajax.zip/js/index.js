/**
 *  QUẢN LÝ SINH VIÊN
 * ** Phân rã chức năng
 *   1. Thêm sinh viên mới vào danh sách
 *   2. Xem ds toàn bộ sinh viên
 *   3. Cập nhật thông tin sinh viên
 *   4. Xoá sinh viên ra khỏi ds
 *   5. Tìm kiếm sinh viên bằng tên hoăc mã
 *   6. Validation input
 *
 * *** Lên Giao diên
 *
 * *** Phân tích lớp đối tượng : Student (id, name, type, math, physics, chemistry, training, calcAverage())
 *
 * *** Bắt đầu từng chức năng
 *
 */

var studentArr = [];

// function 1: Thêm sinh viên
// var addStudent = function () {
//   if (validateForm() === false) return;

//   // dom input , lấy value
//   var id = document.querySelector("#txtMaSV").value;
//   var fullName = document.querySelector("#txtTenSV").value;
//   var type = document.querySelector("#loaiSV").value;
//   var math = +document.querySelector("#txtDiemToan").value;
//   var physics = +document.querySelector("#txtDiemLy").value;
//   var chemistry = +document.querySelector("#txtDiemHoa").value;
//   var training = +document.querySelector("#txtDiemRenLuyen").value;

//   // kiểm tra id có tồn tại chưa, nếu có báo lỗi => return
//   // duyệt studentArr, lấy từng đối tượng sinh viên có id === id

//   for (var i = 0; i < studentArr.length; i++) {
//     if (studentArr[i].id === id) {
//       console.log("Mã sinh viên đã tồn tại");
//       return;
//     }
//   }

//   // // tạo đối tượng sinh viên
//   var newStudent = new Student(
//     id,
//     fullName,
//     type,
//     math,
//     physics,
//     chemistry,
//     training
//   );

//   // // push đối tượng sinh viên vào studentArr
//   studentArr.push(newStudent);

//   createTable();

//   saveData();

//   console.log(studentArr);
// };

var validateForm = function () {
  var id = document.querySelector("#txtMaSV").value;
  var fullName = document.querySelector("#txtTenSV").value;

  var isValid = true;

  isValid &=
    checkRequired(id, "studentIdError") &&
    checkLength(id, "studentIdError", 6, 8);

  isValid &=
    checkRequired(fullName, "nameError") && checkText(fullName, "nameError");

  //  isValid &= checkRequired(type, "typeError");

  return isValid;
};

// function 2 : hiện ds toàn bộ sinh viên
var createTable = function (data) {
  if (data === undefined) {
    data = studentArr;
  }
  var content = "";

  for (var i = 0; i < data.length; i++) {
    content += `
        <tr>
            <td>${data[i].maSinhVien}</td>
            <td>${data[i].tenSinhVien}</td>
            <td>${data[i].loaiSinhVien}</td>
            <td>9.8</td>
            <td>${data[i].diemRenLuyen}</td>
            <td>
                <button onclick="deleteStudent('${data[i].maSinhVien}')" class="btn btn-danger">Xoá</button>
                <button onclick="getStudentToUpdate('${data[i].maSinhVien}')" class="btn btn-info">Sửa</button>
            </td>
        </tr>
    `;
  }

  // console.log(content);

  document.querySelector("#tbodySinhVien").innerHTML = content;
};

//function 3: Xoá sinh viên ra khỏi ds
// var deleteStudent = function (id) {
//   // tìm vị trí theo id
//   var index = findById(id);

//   if (index !== -1) {
//     studentArr.splice(index, 1);
//     createTable();

//     saveData();
//   }
// };

// function 4.1: Lấy sinh viên muon sửa
// var getStudentToUpdate = function (id) {
//   var index = findById(id);
//   // => sinh viên cần sửa:  studentArr[index]

//   document.querySelector("#txtMaSV").value = studentArr[index].id;
//   document.querySelector("#txtTenSV").value = studentArr[index].name;
//   document.querySelector("#loaiSV").value = studentArr[index].type;
//   document.querySelector("#txtDiemToan").value = studentArr[index].math;
//   document.querySelector("#txtDiemLy").value = studentArr[index].physics;
//   document.querySelector("#txtDiemHoa").value = studentArr[index].chemistry;
//   document.querySelector("#txtDiemRenLuyen").value = studentArr[index].training;

//   // document.querySelector("#txtMaSV").style.backgroundColor = "red";
//   // document
//   //   .querySelector("#txtMaSV")
//   //   .setAttribute("style", "background-color: green");
//   // setAttribute: id, class, style, disabled...

//   document.querySelector("#txtMaSV").setAttribute("disabled", true);

//   document.querySelector("#btnAdd").style.display = "none";
//   document.querySelector("#btnUpdate").style.display = "inline";
// };

// function 4.2: lưu thông tin đã chỉnh sửa
// var updateStudent = function () {
//   var id = document.querySelector("#txtMaSV").value;
//   var fullName = document.querySelector("#txtTenSV").value;
//   var type = document.querySelector("#loaiSV").value;
//   var math = +document.querySelector("#txtDiemToan").value;
//   var physics = +document.querySelector("#txtDiemLy").value;
//   var chemistry = +document.querySelector("#txtDiemHoa").value;
//   var training = +document.querySelector("#txtDiemRenLuyen").value;

//   var index = findById(id);
//   // sinh viên đang cần chỉnh sửa: studenArr[index]
//   studentArr[index].name = fullName;
//   studentArr[index].type = type;
//   studentArr[index].math = math;
//   studentArr[index].physics = physics;
//   studentArr[index].chemistry = chemistry;
//   studentArr[index].training = training;

//   createTable();

//   saveData();

//   // clear form
//   document.querySelector("#btnReset").click();

//   // ẩn button cập nhật, hiện button add
//   document.querySelector("#btnAdd").style.display = "inline";
//   document.querySelector("#btnUpdate").style.display = "none";

//   // gỡ disabled cho ô mã sv
//   document.querySelector("#txtMaSV").removeAttribute("disabled");
// };

// function 5: tìm kiếm sinh viên
var findStudents = function () {
  var result = [];
  var keyword = document.querySelector("#txtSearch").value.toLowerCase();

  for (var i = 0; i < studentArr.length; i++) {
    var studentName = studentArr[i].name.toLowerCase();
    if (
      studentArr[i].id === keyword ||
      studentName.includes(keyword) === true
    ) {
      result.push(studentArr[i]);
    }
  }

  createTable(result);
};

var findById = function (id) {
  for (var i = 0; i < studentArr.length; i++) {
    if (studentArr[i].id === id) {
      return i;
    }
  }

  return -1;
  //return vị trí, return -1
};

var saveData = function () {
  // console.log(JSON.stringify(studentArr));
  localStorage.setItem("students", JSON.stringify(studentArr));
};

var fetchData = function () {
  //promise: pending, fulfill, reject
  axios({
    url: "http://svcy.myclass.vn/api/SinhVienApi/LayDanhSachSinhVien",
    method: "GET",
  })
    .then(function (res) {
      // console.log(res.data);
      studentArr = res.data;
      createTable();
    })
    .catch(function (err) {
      console.log(err);
    });
};

fetchData();

// ------ VIDATIONS INPUT : required, minlength, maxlength, pattern ------

var checkRequired = function (value, errorMessageId) {
  if (value.length > 0) {
    document.getElementById(errorMessageId).innerHTML = "";
    return true;
  }
  document.getElementById(errorMessageId).innerHTML =
    "* Trường này bắt buộc nhập";
  return false;
};

var checkLength = function (value, errorMessageId, min, max) {
  if (value.length >= min && value.length <= max) {
    document.getElementById(errorMessageId).innerHTML = "";
    return true;
  }
  document.getElementById(
    errorMessageId
  ).innerHTML = `* Độ dài phải từ ${min} tới ${max} kí tự`;
  return false;
};

var checkText = function (value, errorMessageId) {
  var pattern = /^[A-Za-z\s]+$/g;
  if (pattern.test(value) === true) {
    document.getElementById(errorMessageId).innerHTML = "";
    return true;
  }
  document.getElementById(errorMessageId).innerHTML = "* Vui lòng nhập chữ";
  return false;
};

// có 2 cách để khởi tạo function
// declaration function : có hoisting
// sum1();
// function sum1(a, b) {
//   console.log(a + b);
// }

// expression function : không có hoisting

// var sum2 = function (a, b) {
//   console.log(a + b);
// };
// sum2();

// hoisting: cho phép dùng 1 biến trước khi khai báo

// console.log(a);
// var a = 5;
// console.log(a);
// ---------------------------------- post : add student-----------------


function addStudent() {
  //Lấy thông tin từ người dùng nhập vào lưu vào object có format giống server qui định
  var student = new Student();
  student.maSinhVien = document.getElementById('txtMaSV').value;
  student.tenSinhVien = document.getElementById('txtTenSV').value;
  student.loaiSinhVien = document.getElementById('loaiSV').value;
  student.diemToan = document.getElementById('txtDiemToan').value;
  student.diemLy = document.getElementById('txtDiemToan').value;
  student.diemHoa = document.getElementById('txtDiemToan').value;
  student.diemRenLuyen = document.getElementById('txtDiemRenLuyen').value;

  console.log('student', student);

  // gọi api đưa dữ liệu về server 
  axios({
    url: 'http://svcy.myclass.vn/api/SinhVienApi/ThemSinhVien123',//Đường dẫn api backend qui định
    method: 'POST', //phương thức do backend qui định
    data: student //Dữ liệu gửi đến server format backend qui định
  }).then(function (result) {
    console.log(result.data);
    //Sau khi thêm dữ liệu thành công => gọi lại api lấy dữ liệu từ server về
    fetchData();
  }).catch(function (error) {
    console.log(error.response.data)
  })

}



function deleteStudent(maSinhVien) {
  console.log('maSinhVien', maSinhVien);

  axios({
    url: 'http://svcy.myclass.vn/api/SinhVienApi/XoaSinhVien?maSinhVien=' + maSinhVien,
    method: 'DELETE',
  }).then(function (result) {

    console.log('result', result.data);
    //Sau khi xoá thành công load lại api get laydanhsachsinhvien
    fetchData();

  }).catch(function (errors) {
    console.log('errors', errors.response.data)
  })
}

// ---------------------------- edit ---------------------------
var getStudentToUpdate = function (maSinhVien) {
  console.log('maSinhVien', maSinhVien);

  axios({
    url: 'http://svcy.myclass.vn/api/SinhVienApi/LayThongTinSinhVien?maSinhVien=' + maSinhVien,
    method: 'GET'
  }).then(function (result) {
    console.log(result.data);

    var student = result.data;
    //Lấy dữ liệu đưa lên các input control phía trên 

    document.querySelector("#txtMaSV").value = student.maSinhVien;
    document.querySelector("#txtTenSV").value = student.tenSinhVien;
    document.querySelector("#loaiSV").value = student.loaiSinhVien;
    document.querySelector("#txtDiemToan").value = student.diemToan;
    document.querySelector("#txtDiemLy").value = student.diemLy;
    document.querySelector("#txtDiemHoa").value = student.diemHoa;
    document.querySelector("#txtDiemRenLuyen").value = student.diemRenLuyen;

    document.querySelector('#btnUpdate').style.display = 'block';

  }).catch(function (errors) {
    console.log(errors.response.data);
  })

}

//--------------------------- update ----------------------------
function updateStudent () {
    //Lấy thông tin người dùng nhập từ giao diện điền vào object với định dạng backend qui định
    var student = new Student();
    student.maSinhVien = document.getElementById('txtMaSV').value;
    student.tenSinhVien = document.getElementById('txtTenSV').value;
    student.loaiSinhVien = document.getElementById('loaiSV').value;
    student.diemToan = document.getElementById('txtDiemToan').value;
    student.diemLy = document.getElementById('txtDiemToan').value;
    student.diemHoa = document.getElementById('txtDiemToan').value;
    student.diemRenLuyen = document.getElementById('txtDiemRenLuyen').value;

    axios({
      url:'http://svcy.myclass.vn/api/SinhVienApi/CapNhatThongTinSinhVien?maSinhVien='+student.maSinhVien, //backend qui định
      method:'PUT', //backend qui định
      data: student //định dạng object theo backend qui định
    }).then(function(result) {
      console.log('result',result.data);
      //
      fetchData();
    }).catch(function (error){
      console.log('errors',error.response.data);
    })
}

