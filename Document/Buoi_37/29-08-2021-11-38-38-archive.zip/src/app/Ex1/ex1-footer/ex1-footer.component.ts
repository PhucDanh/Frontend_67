import { Component } from '@angular/core';
// decorator
@Component({
  selector: 'app-ex1-footer',
  templateUrl: './ex1-footer.component.html',
  styleUrls: ['./ex1-footer.component.scss'],
})
export class Ex1Footer {}
