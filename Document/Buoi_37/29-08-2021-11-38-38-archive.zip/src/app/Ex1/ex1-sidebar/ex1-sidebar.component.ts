import { Component } from '@angular/core';
// decorator
@Component({
  selector: 'app-ex1-sidebar',
  templateUrl: './ex1-sidebar.component.html',
  styleUrls: ['./ex1-sidebar.component.scss'],
})
export class Ex1Sidebar {}
