import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { Ex1Content } from './Ex1/ex1-content/ex1-content.component';
import { Ex1Footer } from './Ex1/ex1-footer/ex1-footer.component';
import { Ex1Header } from './Ex1/ex1-header/ex1-header.component';
import { Ex1Home } from './Ex1/ex1-home/ex1-home.component';
import { Ex1Sidebar } from './Ex1/ex1-sidebar/ex1-sidebar.component';
import { Header } from './header/header.component';
import { DemoDataBindingComponent } from './demo-data-binding/demo-data-binding.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    Header,
    Ex1Content,
    Ex1Footer,
    Ex1Header,
    Ex1Home,
    Ex1Sidebar,
    DemoDataBindingComponent,
  ],
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
