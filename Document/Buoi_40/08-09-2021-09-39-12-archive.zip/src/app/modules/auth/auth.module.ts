import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SingInComponent } from './sing-in/sing-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';

@NgModule({
  declarations: [SingInComponent, SignUpComponent],
  imports: [CommonModule],
  exports: [SingInComponent, SignUpComponent],
})
export class AuthModule {}
