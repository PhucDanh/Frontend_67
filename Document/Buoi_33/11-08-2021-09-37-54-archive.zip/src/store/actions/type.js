export const actionType = {
  SET_COURSES: "SET_COURSES",
  SET_COURSE: "SET_COURSE",
  SET_ME: "SET_ME",
};
