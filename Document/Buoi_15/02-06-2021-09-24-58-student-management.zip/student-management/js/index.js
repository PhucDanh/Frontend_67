/**
 *  QUẢN LÝ SINH VIÊN
 * ** Phân rã chức năng
 *   1. Thêm sinh viên mới vào danh sách
 *   2. Xem ds toàn bộ sinh viên
 *   3. Cập nhật thông tin sinh viên
 *   4. Xoá sinh viên ra khỏi ds
 *   5. Tìm kiếm sinh viên bằng tên hoăc mã
 *   6. Validation input
 *
 * *** Lên Giao diên
 *
 * *** Phân tích lớp đối tượng : Student (id, name, type, math, physics, chemistry, training, calcAverage())
 *
 * *** Bắt đầu từng chức năng
 *
 */

var studentArr = [];

// function 1: Thêm sinh viên
var addStudent = function () {
  // dom input , lấy value
  var id = document.querySelector("#txtMaSV").value;
  var fullName = document.querySelector("#txtTenSV").value;
  var type = document.querySelector("#loaiSV").value;
  var math = +document.querySelector("#txtDiemToan").value;
  var physics = +document.querySelector("#txtDiemLy").value;
  var chemistry = +document.querySelector("#txtDiemHoa").value;
  var training = +document.querySelector("#txtDiemRenLuyen").value;

  // kiểm tra id có tồn tại chưa, nếu có báo lỗi => return
  // duyệt studentArr, lấy từng đối tượng sinh viên có id === id

  for (var i = 0; i < studentArr.length; i++) {
    if (studentArr[i].id === id) {
      console.log("Mã sinh viên đã tồn tại");
      return;
    }
  }

  // tạo đối tượng sinh viên
  var newStudent = new Student(
    id,
    fullName,
    type,
    math,
    physics,
    chemistry,
    training
  );

  // push đối tượng sinh viên vào studentArr
  studentArr.push(newStudent);

  createTable();

  saveData();

  console.log(studentArr);
};

// function 2 : hiện ds toàn bộ sinh viên
var createTable = function () {
  var content = "";

  for (var i = 0; i < studentArr.length; i++) {
    content += `
        <tr>
            <td>${studentArr[i].id}</td>
            <td>${studentArr[i].name}</td>
            <td>${studentArr[i].type}</td>
            <td>9.8</td>
            <td>${studentArr[i].training}</td>
            <td>
                <button onclick="deleteStudent('${studentArr[i].id}')" class="btn btn-danger">Xoá</button>
            </td>
        </tr>
    `;
  }

  console.log(content);

  document.querySelector("#tbodySinhVien").innerHTML = content;
};

//function 3: Xoá sinh viên ra khỏi ds
var deleteStudent = function (id) {
  // tìm vị trí theo id
  var index = findById(id);

  if (index !== -1) {
    studentArr.splice(index, 1);
    createTable();
  }
};

var findById = function (id) {
  for (var i = 0; i < studentArr.length; i++) {
    if (studentArr[i].id === id) {
      return i;
    }
  }

  return -1;
  //return vị trí, return -1
};

var saveData = function () {
  console.log(JSON.stringify(studentArr));
  localStorage.setItem("students", JSON.stringify(studentArr));
};

var fetchData = function () {
  var studentJSON = localStorage.getItem("students");
  if (studentJSON !== null) {
    studentArr = JSON.parse(studentJSON);

    createTable();
  }
};

fetchData();

// có 2 cách để khởi tạo function
// declaration function : có hoisting
// sum1();
// function sum1(a, b) {
//   console.log(a + b);
// }

// expression function : không có hoisting

// var sum2 = function (a, b) {
//   console.log(a + b);
// };
// sum2();

// hoisting: cho phép dùng 1 biến trước khi khai báo

// console.log(a);
// var a = 5;
// console.log(a);
