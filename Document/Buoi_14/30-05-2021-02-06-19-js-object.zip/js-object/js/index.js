// Object
var student1 = {
  // key:value
  name: "hieu",
  age: 18,
  email: "hieu@covergo.com",
  //method
  //   calcAverage: function () {
  // return 9;
  // },
  calcAverage() {
    return 9;
  },
};

var student2 = {
  // key:value
  name: "dung",
  age: 19,
  email: "dung@covergo.com",

  //method
  calcAverage() {
    return 1;
  },
};

console.log(student1.name, student1.age, student1.calcAverage());
console.log(student2.name, student2.age, student2.calcAverage());

// tạo một lớp đối tượng Chó

function Dog(name, age, height, weight, breed, hasBirthCertificate) {
  this.name = name;
  this.age = age;
  this.height = height;
  this.weight = weight;
  this.breed = breed;
  this.hasBirthCertificate = hasBirthCertificate;

  this.bark = function () {
    return this.name + " " + this.name;
  };
}

var dog1 = new Dog("Alice", 20, 10, 5, "corgi", true);
var dog2 = new Dog("Lisa", 30, 10, 10, "Alaska", false);

console.log(dog1, dog2, dog1.bark(), dog2.bark());

// var dog1 = {
//   name: "Alice",
//   age: 20,
//   height: 10,
//   weight: 5,
//   breed: "corgi",
//   hasBirthCertificate: true,

//   bark() {
//     return this.name + " " + this.name;
//   },
// };

// var dog2 = {
//   name: "Lisa",
//   age: 40,
//   height: 20,
//   weight: 10,
//   breed: "Alaska",
//   hasBirthCertificate: true,

//   bark() {
//     return this.name + " " + this.name;
//   },
// };

// var dogCenter = {
//   name: "cyberDog",
//   address: "89 Hùng vương",
//   ceo: {
//     name: "Hieu",
//     age: 26,
//   },
//   dogs: [dog1, dog2],
// };

// //1 In ra tên Trung tâm
// console.log(dogCenter.name);

// // 2. In ra tên giám đốc trung tâm
// console.log(dogCenter.ceo.name);

// // 3. In ra tên của tất cả chó có trong trung tâm

// for (var i = 0; i < dogCenter.dogs.length; i++) {
//   console.log(dogCenter.dogs[i].name);
// }

// // thêm thuộc tính cho object
// dogCenter.phone = "28390128329";

// // cập nhật thuộc tính cho object
// dogCenter.address = "82 Sư Vạn Hạnh";

// // xoá thuộc tính
// delete dogCenter.address;

// console.log(dogCenter);

// // var a = 5.1273891237912873;
// // a.toFixed(2)
