// // // var n = 101;

// // // while (n <= 100) {
// // //   console.log(n);
// // //   n++;
// // //   //   n += 2;
// // //   //   //n = n + 2
// // // }

// // // do {
// // //   console.log(n);
// // //   n++;
// // // } while (n <= 100);

// // // for

// // // for (var n = 1; n <= 100; n++) {
// // //   console.log(n);
// // // }

// // function printNumber() {
// //   // for (var i = 0; i <= 100; i++) {
// //   //   if (i % 2 === 0) {
// //   //     console.log(i, "là số chẵn");
// //   //   } else {
// //   //     console.log(i, "là số lẻ");
// //   //   }
// //   // }

// //   var i = 0;
// //   while (i <= 100) {
// //     if (i % 2 === 0) {
// //       console.log(i, "là số chẵn");
// //     } else {
// //       console.log(i, "là số lẻ");
// //     }

// //     i++;
// //   }
// // }

// // function sumOfEven(n) {
// //   var total = 0;
// //   for (var i = 1; i <= n; i++) {
// //     if (i % 2 === 0) {
// //       total += i;
// //     }
// //   }
// //   console.log(total);
// // }

// // function calcNumber() {
// //   var count = 0;
// //   for (var i = 0; i <= 1000; i++) {
// //     if (i % 3 === 0) {
// //       count++;
// //     }
// //   }
// //   console.log(count);
// // }

// // function printSquare(n) {
// //   var content = "";
// //   for (var k = 1; k <= n; k++) {
// //     for (var i = 1; i <= n; i++) {
// //       content += "* ";
// //     }
// //     content += "\n";
// //   }

// //   console.log(content);
// // }

// // printSquare(5);

// // // printNumber();

// //------ARRAY -------
// var names = ["hieu", "tai", "dung", "nguyen"];
// var names2 = ["Phu", "Quoc"];
// // var names = new Array("hieu", "tai", "dung");

// //get items from array
// console.log(names[1], names[2]);

// //add item to the end of array
// // names.push("Huyen");

// // //add item to the begin of array
// // names.unshift("Tuan");

// // //delete the last item in array
// // names.pop();

// // //delete the first item in array
// // names.shift();

// // delete any item in array
// // names.splice(1, 2);

// // length of array
// console.log(names.length);

// // concat array
// var allNames = names.concat(names2);

// console.log(allNames);

// console.log(names);

// var numArr = [];

// function addNumber() {
//   var num = +document.getElementById("txtNumber").value;
//   numArr.push(num);
//   console.log(numArr);
// }

// function sumOfOdd() {
//   var sum = 0;
//   for (var i = 0; i < numArr.length; i++) {
//     if (numArr[i] % 2 !== 0) {
//       sum += numArr[i];
//     }
//   }

//   console.log(sum);
// }

// function countNegative() {
//   var count = 0;
//   for (var i = 0; i < numArr.length; i++) {
//     if (numArr[i] < 0) {
//       count++;
//     }
//   }
//   console.log(count);
// }

var gradeList = [];

function addGrades() {
  var txtGrades = document.getElementById("txtGrade").value;
  var grades = txtGrades.split(",");

  for (var i = 0; i < grades.length; i++) {
    gradeList.push(+grades[i]);
  }

  console.log(gradeList);
}

function calcAverage() {
  var sum = 0;
  for (var i = 0; i < gradeList.length; i++) {
    sum += gradeList[i];
  }
  var average = sum / gradeList.length;

  console.log(average);
  console.log(Math.floor(average));
  console.log(Math.ceil(average));
  console.log(Math.round(average));
  console.log(average.toFixed("2"));
}

function findMaxAndSecond() {
  var max = gradeList[0];
  var second = 0;

  for (var i = 1; i < gradeList.length; i++) {
    if (gradeList[i] > max) {
      second = max;
      max = gradeList[i];
    } else if (gradeList[i] > second && gradeList[i] !== max) {
      second = gradeList[i];
    }
  }

  console.log(max, second);
}

// function checkSum() {
//   for (var k = 0; k < gradeList.length; k++) {
//     for (var i = k + 1; i < gradeList.length; i++) {
//       if (gradeList[k] + gradeList[i] === 10) {
//         console.log("co");
//         return true;
//       }
//     }
//   }

//   console.log("khong");
//   return false;
// }

function checkSum() {
  // multiple point: đa điểm (chỉ dùng đc với mảng có thứ tự)
  var i = 0;
  var k = gradeList.length - 1;

  while (i < k) {
    var sum = gradeList[i] + gradeList[k];
    if (sum === 10) {
      console.log("có");
      return true;
    } else if (sum > 10) {
      k--;
    } else {
      i++;
    }
  }

  console.log("không có");
  return false;
}

function swapGrade(i, j) {
  var temp = gradeList[i];
  gradeList[i] = gradeList[j];
  gradeList[j] = temp;
}
//bubble sort
function sortASC() {
  for (var i = 0; i < gradeList.length; i++) {
    for (var k = 0; k < gradeList.length; k++) {
      if (gradeList[k] > gradeList[k + 1]) {
        swapGrade(k, k + 1);
      }
    }
  }

  console.log(gradeList);
}

//big O notation: độ phức tạp của thuật toán (operation , space)

// O(1)
// function sum(a, b) {
//   return a + b;
// }

// function test(array) {
//   // O(n)
//   var sum = 0;

//   for (var i = 0; i < array.length; i++) {
//     sum += array[i];
//   }

//   for (var i = 0; i < array.length; i++) {
//     sum += array[i];
//   }
// }

// function test2(array) {
//   // O(n^2)
//   var sum = 0;

//   for (var k = 0; k < array.length; k++) {
//     for (var i = 0; i < array.length; i++) {
//       sum += array[i];
//     }
//   }
// }
