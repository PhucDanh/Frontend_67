import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-new',
  templateUrl: './movie-new.component.html',
  styleUrls: ['./movie-new.component.scss']
})
export class MovieNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
