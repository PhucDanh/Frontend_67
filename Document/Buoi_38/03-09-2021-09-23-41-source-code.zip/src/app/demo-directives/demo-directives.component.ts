import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-directives',
  templateUrl: './demo-directives.component.html',
  styleUrls: ['./demo-directives.component.scss'],
})
export class DemoDirectivesComponent implements OnInit {
  //auto detection
  isLogin: boolean = false;
  month: number = 1;
  isBooking: boolean = false;

  months: { value: string; label: string; description: string }[] = [
    { value: '1', label: 'Tháng 1', description: 'Tháng 1 có 31 ngày' },
    { value: '2', label: 'Tháng 2', description: 'Tháng 2 có 28 ngày' },
    { value: '3', label: 'Tháng 3', description: 'Tháng 3 có 31 ngày' },
    { value: '4', label: 'Tháng 4', description: 'Tháng 4 có 30 ngày' },
    { value: '5', label: 'Tháng 5', description: 'Tháng 5 có 31 ngày' },
  ];

  bgColor: string = '#ff00ff';

  constructor() {}

  ngOnInit(): void {}

  handleLogin(): void {
    this.isLogin = true;
  }

  handleChange(event: Event): void {
    this.month = +(event.target as HTMLSelectElement).value;
  }

  handleBookTicket(): void {
    this.isBooking = !this.isBooking;
  }
}
