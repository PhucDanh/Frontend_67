import { Component } from '@angular/core';
// decorator
@Component({
  selector: 'app-ex1-content',
  templateUrl: './ex1-content.component.html',
  styleUrls: ['./ex1-content.component.scss'],
})
export class Ex1Content {}
