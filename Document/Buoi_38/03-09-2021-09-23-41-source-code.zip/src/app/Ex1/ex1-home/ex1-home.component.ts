import { Component } from '@angular/core';
// decorator
@Component({
  selector: 'app-ex1-home',
  templateUrl: './ex1-home.component.html',
  styleUrls: ['./ex1-home.component.scss'],
})
export class Ex1Home {}
