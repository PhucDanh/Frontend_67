import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-data-binding',
  templateUrl: './demo-data-binding.component.html',
  styleUrls: ['./demo-data-binding.component.scss'],
})
export class DemoDataBindingComponent implements OnInit {
  fullName: string = 'Dang Trung Hieu';
  age: number = 12;
  
  imgSrc: string = 'https://picsum.photos/200/300';

  description: string = '<h1>Hello</h1>';

  handleShowMessage(): void {
    alert('Hello event binding!!!');
    this.fullName = 'nguyen dungnnngngn';
  }

  handleChange(event: Event): void {
    this.fullName = (event.target as HTMLInputElement).value;
  }

  handleChangeAge(value: string): void {
    this.age = +value;
  }

  constructor() {}

  ngOnInit(): void {}
}
