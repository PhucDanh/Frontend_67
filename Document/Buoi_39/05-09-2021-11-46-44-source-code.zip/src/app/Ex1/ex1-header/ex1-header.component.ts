import { Component } from '@angular/core';
// decorator
@Component({
  selector: 'app-ex1-header',
  templateUrl: './ex1-header.component.html',
  styleUrls: ['./ex1-header.component.scss'],
})
export class Ex1Header {}
