import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ex2IndexComponent } from './ex2-index.component';

describe('Ex2IndexComponent', () => {
  let component: Ex2IndexComponent;
  let fixture: ComponentFixture<Ex2IndexComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ex2IndexComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Ex2IndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
