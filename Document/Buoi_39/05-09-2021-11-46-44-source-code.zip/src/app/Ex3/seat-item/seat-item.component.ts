import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-seat-item',
  templateUrl: './seat-item.component.html',
  styleUrls: ['./seat-item.component.scss'],
})
export class SeatItemComponent implements OnInit {
  @Input() seat!: {
    SoGhe: number;
    TenGhe: string;
    Gia: number;
    TrangThai: boolean;
  };
  @Output() selectSeat = new EventEmitter();

  isBooking: boolean = false;

  constructor() {}

  ngOnInit(): void {}

  handleSelect(): void {
    this.isBooking = !this.isBooking;
    this.selectSeat.emit(this.seat);
  }
}
