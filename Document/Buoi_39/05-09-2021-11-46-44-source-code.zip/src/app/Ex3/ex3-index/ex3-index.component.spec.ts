import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Ex3IndexComponent } from './ex3-index.component';

describe('Ex3IndexComponent', () => {
  let component: Ex3IndexComponent;
  let fixture: ComponentFixture<Ex3IndexComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Ex3IndexComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Ex3IndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
