import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-student-item',
  templateUrl: './student-item.component.html',
  styleUrls: ['./student-item.component.scss'],
})
export class StudentItemComponent implements OnInit {
  @Input() student!: { name: string; age: number };
  @Input() className: string | undefined;
  @Output() selectMonitor = new EventEmitter();
  @Output() selectViceMonitor = new EventEmitter();
  constructor() {}

  ngOnInit(): void {}

  handleSelectMonitor(): void {
    this.selectMonitor.emit(this.student.name);
  }

  handleSelectViceMonitor(): void {
    this.selectViceMonitor.emit(this.student.name);
  }
}
