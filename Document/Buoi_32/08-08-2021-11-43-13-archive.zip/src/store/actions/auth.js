import axios from "axios";
import { createAction } from "./index";
import { actionType } from "./type";
export const signIn = (userLogin) => {
  return (dispatch) => {
    axios({
      url: "https://elearning0706.cybersoft.edu.vn/api/QuanLyNguoiDung/DangNhap",
      method: "POST",
      data: userLogin,
    })
      .then((res) => {
        dispatch( createAction(actionType.SET_ME, res.data) );
      })
      .catch((err) => {
        console.log({ ...err }, err.response.data);
        alert(err.response.data);
      });
  };
};
