//action creator
export const createAction = (type, payload) => {
  return {
    type,
    payload,
  };
};
