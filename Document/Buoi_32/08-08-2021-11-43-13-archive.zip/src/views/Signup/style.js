const styles = () => {
  return {
    formInput: {
      marginBottom: 20,
    },
  };
};

export default styles;
