class FillInBlank extends Question {
  constructor(type, id, content, answers) {
    super(type, id, content, answers);
  }

  checkExact() {}

  render() {
    return `
          <div>
              <h3>Câu hỏi: ${this.content} </h3>
              <input />
          </div>
        `;
  }
}
