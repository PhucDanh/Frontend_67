class MultipleChoice extends Question {
  constructor(type, id, content, answers) {
    super(type, id, content, answers);
  }

  checkExact() {}

  render() {
    let answersHTML = "";

    for (let item of this.answers) {
      answersHTML += `
            <div>
                <input type="radio" />
                <label >${item.content}</label>
            </div>
        `;
    }

    return `
        <div>
            <h3>Câu hỏi: ${this.content} </h3>
            ${answersHTML}
        </div>
      `;
  }
}

const newQuestion = new MultipleChoice("1", "13232", "Hôm nay là thứ mấy?", [
  { content: "Thứ 2" },
  { content: "Thứ 5" },
  { content: "Thứ 7" },
  { content: "CN" },
]);

console.log(newQuestion.render());
