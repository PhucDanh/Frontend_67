/**
 * PROJECT: Trắc nghiệm online
 *   1. Chức năng cơ bản:
 *      Hiện danh sách câu hỏi
 *      Chấm điểm
 *   2. Lên mockup
 *   3. Phân tích lớp đối tượng
 */

const fetchQuestions = () => {
  axios({
    url: "https://5bd2959ac8f9e400130cb7e9.mockapi.io/api/questions",
    method: "GET",
  })
    .then((res) => {
      console.log(res);
      const mappedQuestion = mapData(res.data);
      renderQuestions(mappedQuestion);
    })
    .catch((err) => {
      console.log(err);
    });
};

const renderQuestions = (data) => {
  let questionsHTML = "";
  for (let item of data) {
    questionsHTML += item.render();
  }
  document.getElementById("questions").innerHTML = questionsHTML;
};

const mapData = (data) => {
  const mappedData = data.map((item) => {
    if (item.questionType === 1) {
      return new MultipleChoice(
        item.questionType,
        item.id,
        item.content,
        item.answers
      );
    }
    return new FillInBlank(
      item.questionType,
      item.id,
      item.content,
      item.answers
    );
  });

  return mappedData;
};

fetchQuestions();

//DEMO MAP FUNCTION

var students = [{ name: "hieu" }, { name: "dung" }];
// => studentNames = ["hieu", "dung"]

const studentNames = students.map((item) => {
  return item.name;
});

const movies = [
  { name: "avenger", rating: 5, id: 1, description: "abc" },
  { name: "Hobbit", rating: 4, id: 2, description: "jkoi" },
];

// showingMovies = [{name: "avenger", id: 1},{name: "Hobbit", id: 2}]

const showingMovies = movies.map((item) => {
  return { name: item.name, id: item.id };
});

console.log(studentNames);
